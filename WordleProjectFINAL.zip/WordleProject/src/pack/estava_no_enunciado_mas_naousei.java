/*

		
// enunciado
		 * 
		 * 
Game(ColorImage bg) //cria um objeto game a partir da CI bg
	{
		Dictionary dicionario = new Dictionary(DICIONARIO_DEFAULT);
		String palavra_puzzle = dicionario.generateSecretWord(Constantes.MAX_CHARS);
		
		inicializa_jogo(bg, dicionario, palavra_puzzle);
	}
		
	Game(Dictionary dicionario) //cria um objeto game a partir do dicionario
	{
		ColorImage bg = new ColorImage(Constantes.DEFAULT_HEIGHT,Constantes.DEFAULT_WIDTH,Constantes.DEFAULT_BG);
		String palavra_puzzle = dicionario.generateSecretWord(Constantes.MAX_CHARS);
			
		inicializa_jogo(bg, dicionario, palavra_puzzle);
		
		if(tentativa.equals(palavra_puzzle)){
				 for(int i = 0; i < tentativa.length(); i++){
						this.tentativas[linha_atual][i] = tentativa.charAt(i);
						System.out.println("Acertastes mesmo em cheio :)");// TODO: aparece primeiro o aviso do que a palavra escrita	
		
		
		
		
		
		
		
		
		
		
	}






















*/